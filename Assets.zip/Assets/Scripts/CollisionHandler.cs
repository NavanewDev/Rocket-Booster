using NUnit.Framework;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class CollisionHandler : MonoBehaviour
{
    [SerializeField] private float delaySeconds = 2f;
    [SerializeField] private AudioClip[] audioClips;
    [SerializeField] private ParticleSystem sucessParticles;
    [SerializeField] private ParticleSystem explotionParticles;
    
    private AudioSource audioSource;
    private bool isControllable = true;
    private bool isCollidable = true;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        RespondToDebugKeys();
    }

    private void RespondToDebugKeys()
    {
        if(Keyboard.current.lKey.wasPressedThisFrame)
        {
            //LoadNxtScene();
        }
        else if(Keyboard.current.cKey.wasPressedThisFrame)
        {
            //isCollidable = !isCollidable;
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if(!isControllable || !isCollidable) { return; }

        switch(other.gameObject.tag)
        {
            case "start":
                Debug.Log("At the starting pad: " + other.gameObject.tag);
                break;
            case "Finish":
                StartDelaySequence(0);
                break;
            default:
                StartDelaySequence(1);
                break;
        }
    }

    private void StartDelaySequence(int seq)
    {
        isControllable = false;
        audioSource.Stop();
        audioSource.PlayOneShot(audioClips[seq]);
        GetComponent<Movement>().enabled = false;
        if(seq == 1)
        {
            explotionParticles.Play();
            Invoke("LoadCurrentScene", delaySeconds);
        }
        else if(seq == 0)
        {
            sucessParticles.Play();
            Invoke("LoadNxtScene", delaySeconds);
        }
        
    }

    private void LoadNxtScene()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;
        int nxtScene = currentScene + 1;
        if(nxtScene == SceneManager.sceneCountInBuildSettings)
        {
            nxtScene = 0;
        }
        SceneManager.LoadScene(nxtScene);
    }

    private void LoadCurrentScene()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentScene);
        
    }
}
