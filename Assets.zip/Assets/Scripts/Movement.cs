using UnityEngine;
using UnityEngine.InputSystem;

public class Movement : MonoBehaviour
{
    [SerializeField] private InputAction thrust;
    [SerializeField] private InputAction rotation;
    [SerializeField] private float thrustStrength = 100f;
    [SerializeField] private float rotationStrength = 10f;
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip audioClip;
    [SerializeField] private ParticleSystem _mainThrustParticles;
    [SerializeField] private ParticleSystem _leftThrustParticles;
    [SerializeField] private ParticleSystem _rightThrustParticles;

    private Rigidbody rb;

    void OnEnable()
    {
        thrust.Enable();
        rotation.Enable();
    }

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        processThrust();
        processRotation();
    }

    private void processThrust()
    {
        if (thrust.IsPressed())
        {
            rb.AddRelativeForce(Vector3.up * thrustStrength * Time.fixedDeltaTime);
            if(!audioSource.isPlaying)
            {
                audioSource.PlayOneShot(audioClip);
            }
            if(!_mainThrustParticles.isPlaying)
            {
                _mainThrustParticles.Play();
            }
        }
        else
        {
            _mainThrustParticles.Stop();
            audioSource.Stop();
        }
    }

    private void processRotation()
    {
        float rotationInput = rotation.ReadValue<float>();
        if(rotationInput < 0)
        {
            ApplyRotation(rotationStrength);
            if(!_leftThrustParticles.isPlaying)
            {
                _rightThrustParticles.Stop();
                _leftThrustParticles.Play();
            }
        }
        else if(rotationInput > 0)
        {
            ApplyRotation(-rotationStrength);
            if(!_rightThrustParticles.isPlaying)
            {
                _leftThrustParticles.Stop();
                _rightThrustParticles.Play();
            }
        }
        else
        {
            _leftThrustParticles.Stop();
            _rightThrustParticles.Stop();
        }
    }

    private void ApplyRotation(float rotationValue)
    {
        rb.freezeRotation = true;
        transform.Rotate(Vector3.forward * rotationValue * Time.fixedDeltaTime);
        rb.freezeRotation = false;
    }
}
